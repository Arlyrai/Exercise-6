</div> 
    <footer>
        <div style="text-align: center; padding: 20px; background-color: #007BFF; color: #fff;">
            <p>&copy; GROUP 6</p>
        </div>
    </footer>
    <script src="jscript.js"></script>
</body>
</html>
